import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

  private int[][] directions = new int[][] { { 1, 0 }, // BOTTOM
      { -1, 0 }, // TOP
      { 0, -1 }, // LEFT
      { 0, 1 } // RIGHT
  };

  private int n;
  private int[] grid;
  private WeightedQuickUnionUF uf;
  private WeightedQuickUnionUF uf2;

  public Percolation(int n) {

    if (n <= 0) {
      throw new java.lang.IllegalArgumentException();
    }

    this.n = n;

    // add two phantom nodes, one connected to all the elements of the top row,
    // and one connected to all the ones at the bottom row
    uf = new WeightedQuickUnionUF((n * n) + 2);
    uf2 = new WeightedQuickUnionUF((n * n) + 1);

    for (int i = 1; i < n + 1; i++) {
      uf.union(i, 0);
      uf2.union(i, 0);
    }

    for (int i = n * n; i > n * n - n; i--) {
      uf.union(i, (n * n) + 1);
    }

    // create n-by-n grid, with all sites blocked
    // No need to keep a multidimensional array
    grid = new int[n * n];

    for (int i = 0; i < n * n; i++) {
      grid[i] = 0; // Initialize all to full
    }
  }

  // open site (row i, column j) if it is not open already
  public void open(int i, int j) {
    if (!isValidCoordinate(i, j)) {
      throw new java.lang.IndexOutOfBoundsException();
    }

    int tmpi = i;
    int tmpj = j;

    if (isBlocked(i, j)) {
      // it is full, let's open it
      grid[getIndex(i, j)] = 1;

      for (int d = 0; d < directions.length; d++) {
        i = tmpi + directions[d][0];
        j = tmpj + directions[d][1];

        // if a cell in one of the allowed directions is open we can perform a
        // connection
        if (isValidCoordinate(i, j) && isOpen(i, j)) {
          // we add 1 because of the trick in the constructor everything is
          // shifted by one in the UF structure
          int cellA = getIndex(i, j) + 1;
          int cellB = getIndex(tmpi, tmpj) + 1;
          uf.union(cellA, cellB);
          uf2.union(cellA, cellB);
        }
      }

    }
  }

  // is site (row i, column j) open?
  public boolean isOpen(int i, int j) {
    if (isValidCoordinate(i, j)) {
      return grid[getIndex(i, j)] == 1;
    }
    throw new java.lang.IndexOutOfBoundsException();
  }

  // is site (row i, column j) full?
  public boolean isFull(int i, int j) {
    if (isValidCoordinate(i, j)) {
      if (isOpen(i, j)) {
        int index = getIndex(i, j) + 1;
        if (index < n) {
          // by definition an open site at the first row is full
          return true;
        }

        return uf2.connected(index, 0);
      }
    } else {
      throw new java.lang.IndexOutOfBoundsException();
    }

    return false;
  }

  private boolean isBlocked(int i, int j) {
    if (isValidCoordinate(i, j)) {
      return grid[getIndex(i, j)] == 0;
    }
    return false;
  }

  // does the system percolate?
  public boolean percolates() {
    // we don't use the isFull definition
    int virtualTop = 0;
    int virtualBottom = n * n + 1;

    // corner case: 1 site
    if (virtualBottom == 2) {
      return isOpen(1, 1);
    }

    // corner case: no sites
    if (virtualBottom == 0) {
      return false;
    }

    return uf.connected(virtualTop, virtualBottom);
  }

  // get single index from row and column
  private int getIndex(int i, int j) {
    return (i - 1) * n + (j - 1);
  }

  private boolean isValidCoordinate(int i, int j) {
    if (i > 0 && i <= n && j > 0 && j <= n) {
      return true;
    }

    return false;
  }
}